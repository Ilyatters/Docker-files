
import psycopg2

conn_params = {
    'dbname': 'my_hw_db',
    'user': 'postgres',
    'password': '    ',
    'host': 'localhost',
    'port': '5432'
}

try:
    conn = psycopg2.connect(**conn_params)
    cursor = conn.cursor()

    cursor.execute('DROP TABLE IF EXISTS for_hw;')

    create_table_query = """
    CREATE TABLE for_hw (
        id SERIAL PRIMARY KEY,
        city VARCHAR(40),
        district VARCHAR(40),
        address VARCHAR(100),
        area NUMERIC(10,2),
        rooms INT,
        floor INT,
        year_built INT,
        price NUMERIC(10,2),
        type VARCHAR(40)
        )
    """

    cursor.execute(create_table_query)
    conn.commit()

    insert_querry = """
    INSERT INTO for_hw (city, district, address, area, rooms, floor, year_built, price, type)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);
    """
    data = [
        ('Москва', 'Центральный', 'ул. Тверская, 50', 75.5, 3, 5, 1990, 12000000, 'квартира'),
        ('Санкт-Петербург', 'Василеостровский', 'пр. Большой В.О., 30', 60.0, 2, 3, 1985, 8500000, 'квартира'),
        ('Екатеринбург', 'Кировский', 'ул. Малышева, 45', 90.0, 4, 7, 2005, 9500000, 'квартира'),
        ('Новосибирск', 'Ленинский', 'ул. Красный проспект, 20', 45.0, 1, 2, 1975, 4000000, 'квартира'),
        ('Казань', 'Вахитовский', 'ул. Баумана, 15', 85.0, 3, 6, 2010, 11000000, 'квартира'),
        ('Краснодар', 'Центральный', 'ул. Красная, 100', 65.0, 2, 4, 2000, 7000000, 'квартира'),
        ('Сочи', 'Адлерский', 'ул. Ленина, 10', 120.0, 5, 10, 2015, 15000000, 'квартира'),
        ('Нижний Новгород', 'Советский', 'ул. Белинского, 25', 70.0, 3, 5, 1995, 6000000, 'квартира'),
        ('Владивосток', 'Первомайский', 'ул. Светланская, 50', 55.0, 2, 3, 1980, 5500000, 'квартира'),
        ('Ростов-на-Дону', 'Железнодорожный', 'ул. Большая Садовая, 40', 95.0, 4, 8, 2008, 9000000, 'квартира')
    ]

    cursor.executemany(insert_querry, data)
    conn.commit()

    print('Таблица for_hw успешно создана и заполнена данными')

except Exception as e:
    print('Ошибка:', e)

finally:
    if cursor:
        cursor.close()
    if conn:
        conn.close()


import pandas as pd
from sqlalchemy import create_engine

engine = create_engine('postgresql+psycopg2://postgres:    @localhost:5432/my_hw_db')
df = pd.read_sql("SELECT * FROM for_hw WHERE price < 5000000", engine)

print(df)