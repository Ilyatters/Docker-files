CREATE DATABASE mydatabase;

\c mydatabase;

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,   
);

INSERT INFO users(username, email) VALUES
('bob', 'bob@gmail.com'),
('jonh', 'jonh@gmail.com');